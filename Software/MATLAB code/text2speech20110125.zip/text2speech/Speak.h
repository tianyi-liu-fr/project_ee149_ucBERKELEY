#ifndef _TEXT2SPEECH_H_
#define _TEXT2SPEECH_H_

#ifndef EXPORT
#define EXPORT
#endif

EXPORT void Speak( char*);

#endif 
